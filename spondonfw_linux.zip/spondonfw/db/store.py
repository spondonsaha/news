"""
SpondonFW - DB: Result Store
Abstraction layer over SQLite (default), PostgreSQL, or MongoDB.
All module results are persisted here for querying and reporting.
"""
import json
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


DB_PATH = Path("data/spondonfw.db")


class ResultStore:
    """
    Stores ModuleResult objects in SQLite (default).
    Swap backend by setting DB_TYPE env var: sqlite | postgres | mongo
    """

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = Path(db_path or DB_PATH)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _conn(self):
        return sqlite3.connect(str(self.db_path))

    def _init_schema(self):
        with self._conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS results (
                    id          TEXT PRIMARY KEY,
                    session_id  TEXT,
                    module      TEXT NOT NULL,
                    target      TEXT NOT NULL,
                    status      TEXT NOT NULL,
                    findings    TEXT,          -- JSON array
                    raw_output  TEXT,
                    error       TEXT,
                    started_at  REAL,
                    finished_at REAL,
                    duration    REAL,
                    metadata    TEXT,          -- JSON object
                    created_at  TEXT DEFAULT (datetime('now'))
                );

                CREATE TABLE IF NOT EXISTS findings (
                    id          TEXT PRIMARY KEY,
                    result_id   TEXT NOT NULL,
                    session_id  TEXT,
                    module      TEXT,
                    target      TEXT,
                    type        TEXT NOT NULL,
                    value       TEXT,
                    severity    TEXT DEFAULT 'info',
                    url         TEXT,
                    evidence    TEXT,
                    notes       TEXT,
                    timestamp   REAL,
                    FOREIGN KEY (result_id) REFERENCES results(id)
                );

                CREATE INDEX IF NOT EXISTS idx_findings_severity
                    ON findings(severity);
                CREATE INDEX IF NOT EXISTS idx_findings_target
                    ON findings(target);
                CREATE INDEX IF NOT EXISTS idx_findings_type
                    ON findings(type);
                CREATE INDEX IF NOT EXISTS idx_results_session
                    ON results(session_id);
            """)

    def save_result(self, result) -> bool:
        """Persist a ModuleResult to the database."""
        try:
            d = result.to_dict()
            with self._conn() as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO results
                    (id, session_id, module, target, status, findings,
                     raw_output, error, started_at, finished_at, duration, metadata)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                """, (
                    d["id"],
                    d.get("session_id", ""),
                    d["module"],
                    d["target"],
                    d["status"],
                    json.dumps(d["findings"]),
                    d.get("raw_output", "")[:10000],   # cap raw output
                    d.get("error"),
                    d.get("started_at"),
                    d.get("finished_at"),
                    d.get("duration_seconds"),
                    json.dumps(d.get("metadata", {})),
                ))

                # Insert individual findings for fast querying
                for f in d["findings"]:
                    conn.execute("""
                        INSERT OR IGNORE INTO findings
                        (id, result_id, session_id, module, target,
                         type, value, severity, url, evidence, notes, timestamp)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                    """, (
                        f["id"],
                        d["id"],
                        d.get("session_id", ""),
                        d["module"],
                        d["target"],
                        f["type"],
                        str(f["value"])[:2000],
                        f.get("severity", "info"),
                        f.get("url", ""),
                        f.get("evidence", "")[:2000],
                        f.get("notes", ""),
                        f.get("timestamp"),
                    ))
            return True
        except Exception as e:
            print(f"[ResultStore] save error: {e}")
            return False

    def get_findings(self, target: Optional[str] = None,
                     session_id: Optional[str] = None,
                     severity: Optional[str] = None,
                     finding_type: Optional[str] = None) -> List[Dict]:
        """Query findings with optional filters."""
        query = "SELECT * FROM findings WHERE 1=1"
        params = []
        if target:
            query += " AND target = ?"
            params.append(target)
        if session_id:
            query += " AND session_id = ?"
            params.append(session_id)
        if severity:
            query += " AND severity = ?"
            params.append(severity)
        if finding_type:
            query += " AND type = ?"
            params.append(finding_type)
        query += " ORDER BY timestamp DESC"

        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]

    def get_summary(self, session_id: str) -> Dict:
        """Return severity summary for a session."""
        with self._conn() as conn:
            rows = conn.execute("""
                SELECT severity, COUNT(*) as count
                FROM findings WHERE session_id = ?
                GROUP BY severity
            """, (session_id,)).fetchall()
            return {row[0]: row[1] for row in rows}

    def get_all_sessions(self) -> List[Dict]:
        with self._conn() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("""
                SELECT session_id, target, MIN(created_at) as started,
                       COUNT(DISTINCT module) as modules_run,
                       COUNT(*) as total_findings
                FROM findings
                GROUP BY session_id, target
                ORDER BY started DESC
            """).fetchall()
            return [dict(r) for r in rows]

    def export_session(self, session_id: str) -> Dict:
        """Export all data for a session as a dict (for reporting)."""
        findings = self.get_findings(session_id=session_id)
        summary = self.get_summary(session_id)
        return {
            "session_id": session_id,
            "summary": summary,
            "findings": findings,
            "total": len(findings),
        }
