"""
SpondonFW - Plugin Loader
Install, list, and load community/custom plugins.

Plugin format
─────────────
plugins/
  my_plugin/
    __init__.py
    plugin.yaml        ← metadata
    module.py          ← BaseModule subclass

plugin.yaml example:
  name: my_plugin
  version: "1.0.0"
  description: "My custom recon module"
  entry: module.MyPluginModule
  register_as: "plugin.my_plugin"
  author: "Your Name"
  tags: [recon, custom]
"""

import importlib.util
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

import yaml

PLUGINS_DIR = Path("plugins/")
PLUGIN_MANIFEST = "plugin.yaml"


class PluginLoader:

    def __init__(self, plugins_dir: Optional[str] = None):
        self.plugins_dir = Path(plugins_dir or PLUGINS_DIR)
        self.plugins_dir.mkdir(parents=True, exist_ok=True)

    # ── Public API ────────────────────────────────────────────────────────────

    def list(self) -> List[Dict]:
        """Return metadata for all installed plugins."""
        plugins = []
        for manifest in self.plugins_dir.rglob(PLUGIN_MANIFEST):
            try:
                with open(manifest) as f:
                    meta = yaml.safe_load(f)
                meta["_path"] = str(manifest.parent)
                plugins.append(meta)
            except Exception:
                continue
        return plugins

    def load(self, plugin_name: str):
        """Load a plugin by name and return its module instance."""
        meta = self._find_plugin(plugin_name)
        if not meta:
            raise ModuleNotFoundError(f"Plugin not found: {plugin_name}")

        entry = meta.get("entry", "")
        module_file, class_name = entry.rsplit(".", 1)
        plugin_path = Path(meta["_path"]) / f"{module_file}.py"

        spec = importlib.util.spec_from_file_location(plugin_name, str(plugin_path))
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)

        cls = getattr(mod, class_name)
        return cls()

    def install(self, source: str):
        """
        Install a plugin from:
        - Local directory path: /path/to/my_plugin
        - Git URL: https://github.com/user/spondonfw-plugin-x
        """
        if source.startswith("http") or source.startswith("git@"):
            self._install_from_git(source)
        else:
            self._install_from_path(source)

    def uninstall(self, plugin_name: str):
        meta = self._find_plugin(plugin_name)
        if not meta:
            raise ModuleNotFoundError(f"Plugin not found: {plugin_name}")
        shutil.rmtree(meta["_path"])

    def register_all(self, loader):
        """Register all installed plugins into the ModuleLoader."""
        for meta in self.list():
            register_as = meta.get("register_as")
            if not register_as:
                continue
            entry = meta.get("entry", "")
            module_file, class_name = entry.rsplit(".", 1)
            plugin_path = str(Path(meta["_path"]) / f"{module_file}.py")
            loader.register(register_as, plugin_path, class_name)

    # ── Private ──────────────────────────────────────────────────────────────

    def _find_plugin(self, name: str) -> Optional[Dict]:
        for p in self.list():
            if p.get("name") == name:
                return p
        return None

    def _install_from_git(self, git_url: str):
        repo_name = git_url.rstrip("/").split("/")[-1].replace(".git", "")
        dest = self.plugins_dir / repo_name
        if dest.exists():
            raise FileExistsError(f"Plugin already installed: {repo_name}")
        result = subprocess.run(
            ["git", "clone", "--depth=1", git_url, str(dest)],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            raise RuntimeError(f"Git clone failed: {result.stderr}")
        print(f"Plugin installed: {repo_name}")

    def _install_from_path(self, path: str):
        src = Path(path)
        if not src.exists():
            raise FileNotFoundError(f"Path not found: {path}")
        manifest = src / PLUGIN_MANIFEST
        if not manifest.exists():
            raise ValueError(f"No {PLUGIN_MANIFEST} found in {path}")
        dest = self.plugins_dir / src.name
        if dest.exists():
            raise FileExistsError(f"Plugin already installed: {src.name}")
        shutil.copytree(str(src), str(dest))
        print(f"Plugin installed: {src.name}")
