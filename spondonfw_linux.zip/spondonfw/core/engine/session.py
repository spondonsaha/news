"""
SpondonFW - Session Manager
Persists and loads scan sessions for resume support.
"""
import json
import time
import uuid
from pathlib import Path
from typing import Dict, List, Optional


SESSIONS_DIR = Path.home() / ".spondonfw" / "sessions"


class SessionManager:

    def __init__(self):
        SESSIONS_DIR.mkdir(parents=True, exist_ok=True)

    def create_session(self, session_id: str, target: str,
                       pipeline: str, output_dir: str) -> Dict:
        session = {
            "id": session_id,
            "target": target,
            "pipeline": pipeline,
            "output_dir": output_dir,
            "status": "running",
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "stage_status": {},
        }
        self._write(session_id, session)
        return session

    def update_session(self, session_id: str, **kwargs):
        session = self._read(session_id) or {}
        session.update(kwargs)
        session["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        self._write(session_id, session)

    def load_last_session(self, target: str) -> Optional[Dict]:
        sessions = self.list_sessions()
        matching = [s for s in sessions if s.get("target") == target
                    and s.get("status") != "completed"]
        if matching:
            return sorted(matching, key=lambda x: x.get("created_at", ""))[-1]
        return None

    def list_sessions(self) -> List[Dict]:
        sessions = []
        for f in SESSIONS_DIR.glob("*.json"):
            try:
                with open(f) as fh:
                    sessions.append(json.load(fh))
            except Exception:
                continue
        return sorted(sessions, key=lambda x: x.get("created_at", ""), reverse=True)

    def show(self, session_id: str):
        s = self._read(session_id)
        if s:
            print(json.dumps(s, indent=2))
        else:
            print(f"Session not found: {session_id}")

    def delete(self, session_id: str):
        p = SESSIONS_DIR / f"{session_id}.json"
        if p.exists():
            p.unlink()

    def _read(self, session_id: str) -> Optional[Dict]:
        p = SESSIONS_DIR / f"{session_id}.json"
        if p.exists():
            with open(p) as f:
                return json.load(f)
        return None

    def _write(self, session_id: str, data: Dict):
        p = SESSIONS_DIR / f"{session_id}.json"
        with open(p, "w") as f:
            json.dump(data, f, indent=2)
