"""
SpondonFW - Base Module
All modules must inherit from BaseModule.
"""

import abc
import time
import uuid
import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from utils.logger import get_logger
from db.store import ResultStore


class ModuleResult:
    """Standardised result container returned by every module."""

    def __init__(self, module_name: str, target: str):
        self.id = str(uuid.uuid4())
        self.module_name = module_name
        self.target = target
        self.status = "pending"       # pending | running | success | failed | skipped
        self.findings: List[Dict] = []
        self.raw_output: str = ""
        self.error: Optional[str] = None
        self.started_at: Optional[float] = None
        self.finished_at: Optional[float] = None
        self.metadata: Dict[str, Any] = {}

    @property
    def duration(self) -> float:
        if self.started_at and self.finished_at:
            return self.finished_at - self.started_at
        return 0.0

    def add_finding(self, finding_type: str, value: Any, severity: str = "info",
                    url: str = "", evidence: str = "", notes: str = ""):
        """Add a structured finding."""
        self.findings.append({
            "id": str(uuid.uuid4()),
            "type": finding_type,
            "value": value,
            "severity": severity,
            "url": url,
            "evidence": evidence,
            "notes": notes,
            "timestamp": time.time()
        })

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "module": self.module_name,
            "target": self.target,
            "status": self.status,
            "findings": self.findings,
            "raw_output": self.raw_output,
            "error": self.error,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "duration_seconds": self.duration,
            "metadata": self.metadata
        }

    def save(self, output_dir: str):
        """Persist result as JSON file."""
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        filepath = out / f"{self.module_name.replace('.', '_')}_{self.id[:8]}.json"
        with open(filepath, "w") as f:
            json.dump(self.to_dict(), f, indent=2)
        return str(filepath)


class BaseModule(abc.ABC):
    """
    Abstract base class for all SpondonFW modules.

    Every module MUST implement:
      - name          : str  (dotted path e.g. 'recon.subdomains')
      - description   : str
      - tools_required: list of tool names
      - input_schema  : dict (what this module expects)
      - output_schema : dict (what this module produces)
      - execute()     : core logic — receives context dict, returns ModuleResult

    Optional overrides:
      - pre_run()     : called before execute (validation, setup)
      - post_run()    : called after execute (cleanup, formatting)
      - can_run()     : returns bool — whether prerequisites are met
    """

    # ── Metadata (override in subclass) ─────────────────────────────────────
    name: str = "base.module"
    description: str = "Abstract base module"
    category: str = "misc"
    tools_required: List[str] = []
    input_schema: Dict = {}
    output_schema: Dict = {}
    tags: List[str] = []

    def __init__(self):
        self.logger = get_logger(self.name)
        self._store = ResultStore()

    # ── Lifecycle ────────────────────────────────────────────────────────────

    def pre_run(self, ctx: Dict) -> None:
        """Optional: setup/validation before execute"""
        pass

    @abc.abstractmethod
    def execute(self, ctx: Dict) -> ModuleResult:
        """
        Core module logic.

        Args:
            ctx: Dictionary with at minimum:
                 - target      : str  (the primary target domain)
                 - output_dir  : str  (where to write files)
                 - session_id  : str
                 - config      : dict (global framework config)
                 - rate_limit  : int  (req/sec)
                 Plus any module-specific keys from input_schema.

        Returns:
            ModuleResult
        """
        pass

    def post_run(self, result: ModuleResult, ctx: Dict) -> ModuleResult:
        """Optional: post-processing after execute"""
        return result

    def can_run(self, ctx: Dict) -> bool:
        """Override to add prerequisite checks."""
        return True

    # ── Public run() — DO NOT OVERRIDE ──────────────────────────────────────

    def run(self, target: str, output_dir: str = "results/", session_id: str = "",
            config: Optional[Dict] = None, **kwargs) -> ModuleResult:
        """
        Orchestrates the full lifecycle: pre_run → execute → post_run.
        Handles timing, error capture, and persistence automatically.
        """
        ctx = {
            "target": target,
            "output_dir": output_dir,
            "session_id": session_id or str(uuid.uuid4()),
            "config": config or {},
            "rate_limit": kwargs.pop("rate_limit", 10),
            **kwargs
        }

        result = ModuleResult(module_name=self.name, target=target)

        if not self.can_run(ctx):
            result.status = "skipped"
            self.logger.warning(f"Module {self.name} skipped — prerequisites not met")
            return result

        try:
            self.pre_run(ctx)
            result.status = "running"
            result.started_at = time.time()
            self.logger.info(f"▶ Running module: {self.name} → {target}")

            result = self.execute(ctx)

            result.status = "success"
            result.finished_at = time.time()
            self.logger.info(f"✓ Module {self.name} complete in {result.duration:.1f}s "
                             f"({len(result.findings)} findings)")

            result = self.post_run(result, ctx)
            result.save(output_dir)

            # Persist to DB
            self._store.save_result(result)

        except KeyboardInterrupt:
            result.status = "interrupted"
            result.error = "User interrupted"
            self.logger.warning(f"Module {self.name} interrupted by user")

        except Exception as e:
            result.status = "failed"
            result.error = str(e)
            result.finished_at = time.time()
            self.logger.error(f"Module {self.name} failed: {e}", exc_info=True)

        return result

    # ── Helpers available to all modules ────────────────────────────────────

    def _run_tool(self, cmd: str, timeout: int = 300) -> str:
        """Run an external shell tool and return stdout."""
        import subprocess
        self.logger.debug(f"Tool cmd: {cmd}")
        try:
            proc = subprocess.run(
                cmd, shell=True, capture_output=True, text=True, timeout=timeout
            )
            if proc.returncode != 0:
                self.logger.debug(f"Tool stderr: {proc.stderr[:500]}")
            return proc.stdout
        except subprocess.TimeoutExpired:
            self.logger.warning(f"Tool timed out after {timeout}s: {cmd}")
            return ""

    def _tool_available(self, tool_name: str) -> bool:
        """Check if a CLI tool is on PATH."""
        import shutil
        return shutil.which(tool_name) is not None

    def _read_lines(self, filepath: str) -> List[str]:
        """Read a file and return non-empty lines."""
        try:
            with open(filepath) as f:
                return [l.strip() for l in f if l.strip()]
        except FileNotFoundError:
            self.logger.warning(f"File not found: {filepath}")
            return []

    def _write_lines(self, filepath: str, lines: List[str]) -> None:
        """Write a list of strings to file."""
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
        with open(filepath, "w") as f:
            f.write("\n".join(lines))
