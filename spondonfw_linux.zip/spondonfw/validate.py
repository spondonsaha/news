#!/usr/bin/env python3
"""
SpondonFW - Quick validation script
Run after cloning to verify structure and imports
"""
import sys
import os
from pathlib import Path

ROOT = Path(__file__).parent

REQUIRED_FILES = [
    "cli/main.py",
    "core/engine/base_module.py",
    "core/engine/session.py",
    "core/pipeline/runner.py",
    "core/loader/module_loader.py",
    "core/loader/plugin_loader.py",
    "modules/recon/subdomains/subdomain_enum.py",
    "modules/enumeration/js_analysis/js_analyzer.py",
    "modules/vulnscan/xss/xss_scanner.py",
    "modules/reporting/report_engine.py",
    "db/store.py",
    "utils/config_parser.py",
    "utils/logger.py",
    "utils/rate_limiter.py",
    "utils/keystore.py",
    "config/pipelines/full_scan.yaml",
    "config/pipelines/recon_only.yaml",
    "requirements.txt",
    "setup.py",
    "README.md",
]

print("SpondonFW — Structure Validation")
print("=" * 40)

all_ok = True
for f in REQUIRED_FILES:
    path = ROOT / f
    exists = path.exists()
    status = "✓" if exists else "✗ MISSING"
    print(f"  {status}  {f}")
    if not exists:
        all_ok = False

print()
if all_ok:
    print("✓ All required files present")
else:
    print("✗ Some files are missing — re-run setup")
    sys.exit(1)

# Check Python version
if sys.version_info < (3, 9):
    print("✗ Python 3.9+ required")
    sys.exit(1)
else:
    print(f"✓ Python {sys.version_info.major}.{sys.version_info.minor}")

# Check key tools
import shutil
tools = ["subfinder", "httpx", "nuclei", "dalfox", "ffuf", "katana",
         "waybackurls", "amass", "assetfinder", "puredns", "arjun"]
print()
print("Tool availability:")
for tool in tools:
    found = shutil.which(tool) is not None
    icon = "✓" if found else "○ not found (install separately)"
    print(f"  {icon}  {tool}")

print()
print("Run: spondonfw --help")
