"""
SpondonFW - Reporting Module: HTML Report Engine
Generates a polished, self-contained HTML report from session findings.
"""

import json
import time
from pathlib import Path
from typing import Dict, List
from db.store import ResultStore


SEVERITY_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
SEVERITY_COLOR = {
    "critical": "#ff3b30",
    "high":     "#ff9500",
    "medium":   "#ffcc00",
    "low":      "#34c759",
    "info":     "#007aff",
}


class ReportEngine:

    def __init__(self, session_id: str, output_dir: str = "reports/"):
        self.session_id = session_id
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.store = ResultStore()

    def generate(self, fmt: str = "html") -> str:
        data = self.store.export_session(self.session_id)
        if fmt == "html":
            return self._generate_html(data)
        elif fmt == "json":
            return self._generate_json(data)
        elif fmt == "markdown":
            return self._generate_markdown(data)
        else:
            raise ValueError(f"Unknown format: {fmt}")

    def _generate_html(self, data: Dict) -> str:
        findings = sorted(
            data["findings"],
            key=lambda f: SEVERITY_ORDER.get(f.get("severity", "info"), 99)
        )

        # Severity counts
        counts = {sev: 0 for sev in SEVERITY_ORDER}
        for f in findings:
            sev = f.get("severity", "info")
            counts[sev] = counts.get(sev, 0) + 1

        # Group findings by type
        by_type: Dict[str, List] = {}
        for f in findings:
            t = f.get("type", "other")
            by_type.setdefault(t, []).append(f)

        # Build finding rows
        rows_html = ""
        for f in findings:
            sev = f.get("severity", "info")
            color = SEVERITY_COLOR.get(sev, "#999")
            rows_html += f"""
            <tr>
                <td><span class="badge" style="background:{color}">{sev.upper()}</span></td>
                <td class="mono">{_esc(f.get('type',''))}</td>
                <td>{_esc(str(f.get('value',''))[:120])}</td>
                <td class="mono small">{_esc(f.get('url','')[:80])}</td>
                <td>{_esc(f.get('notes','')[:100])}</td>
            </tr>"""

        # Severity chart bars
        total = max(data["total"], 1)
        chart_bars = ""
        for sev, cnt in counts.items():
            if cnt == 0:
                continue
            pct = int((cnt / total) * 100)
            color = SEVERITY_COLOR[sev]
            chart_bars += f"""
            <div class="bar-row">
                <span class="bar-label">{sev.capitalize()}</span>
                <div class="bar-track">
                    <div class="bar-fill" style="width:{pct}%;background:{color}"></div>
                </div>
                <span class="bar-count">{cnt}</span>
            </div>"""

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>SpondonFW Report — {data['session_id'][:8]}</title>
<style>
  :root {{
    --bg: #0d0d0d; --surface: #161616; --border: #2a2a2a;
    --text: #e8e8e8; --muted: #888; --accent: #00d4ff;
    --font: 'SF Mono', 'Fira Code', monospace;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: var(--bg); color: var(--text);
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
          font-size: 14px; line-height: 1.6; }}
  .container {{ max-width: 1200px; margin: 0 auto; padding: 2rem; }}
  header {{ border-bottom: 1px solid var(--border); padding-bottom: 1.5rem; margin-bottom: 2rem; }}
  header h1 {{ font-size: 1.6rem; color: var(--accent); letter-spacing: -0.5px; }}
  header p  {{ color: var(--muted); margin-top: 0.25rem; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
           gap: 1rem; margin-bottom: 2rem; }}
  .card {{ background: var(--surface); border: 1px solid var(--border);
           border-radius: 8px; padding: 1.2rem; }}
  .card .num {{ font-size: 2rem; font-weight: 700; color: var(--accent); }}
  .card .label {{ color: var(--muted); font-size: 12px; text-transform: uppercase;
                  letter-spacing: 1px; margin-top: 4px; }}
  .section {{ margin-bottom: 2.5rem; }}
  .section h2 {{ font-size: 1rem; text-transform: uppercase; letter-spacing: 1px;
                 color: var(--muted); border-bottom: 1px solid var(--border);
                 padding-bottom: 0.5rem; margin-bottom: 1rem; }}
  table {{ width: 100%; border-collapse: collapse; }}
  th {{ text-align: left; color: var(--muted); font-size: 11px; text-transform: uppercase;
        letter-spacing: 0.5px; padding: 0.5rem 0.75rem;
        border-bottom: 1px solid var(--border); }}
  td {{ padding: 0.6rem 0.75rem; border-bottom: 1px solid var(--border);
        vertical-align: top; }}
  tr:hover td {{ background: rgba(255,255,255,0.02); }}
  .badge {{ display: inline-block; padding: 2px 8px; border-radius: 4px;
            font-size: 10px; font-weight: 700; letter-spacing: 0.5px;
            color: #000; }}
  .mono {{ font-family: var(--font); font-size: 12px; }}
  .small {{ font-size: 11px; }}
  .bar-row {{ display: flex; align-items: center; gap: 1rem; margin-bottom: 0.5rem; }}
  .bar-label {{ width: 70px; font-size: 12px; text-transform: capitalize; color: var(--muted); }}
  .bar-track {{ flex: 1; background: var(--border); border-radius: 4px; height: 8px; }}
  .bar-fill  {{ height: 100%; border-radius: 4px; transition: width 0.3s; }}
  .bar-count {{ width: 30px; font-size: 12px; text-align: right; color: var(--muted); }}
  footer {{ color: var(--muted); font-size: 11px; text-align: center;
            margin-top: 3rem; padding-top: 1rem; border-top: 1px solid var(--border); }}
</style>
</head>
<body>
<div class="container">

  <header>
    <h1>⚡ SpondonFW — Security Assessment Report</h1>
    <p>Session: <code>{data['session_id']}</code> &nbsp;|&nbsp;
       Generated: {time.strftime('%Y-%m-%d %H:%M:%S')} &nbsp;|&nbsp;
       Total Findings: <strong>{data['total']}</strong></p>
  </header>

  <div class="section">
    <h2>Severity Overview</h2>
    <div class="grid">
      {''.join(f'<div class="card"><div class="num" style="color:{SEVERITY_COLOR[s]}">{counts[s]}</div><div class="label">{s}</div></div>' for s in SEVERITY_ORDER)}
    </div>
    {chart_bars}
  </div>

  <div class="section">
    <h2>All Findings ({data['total']})</h2>
    <table>
      <thead>
        <tr>
          <th>Severity</th><th>Type</th><th>Value</th><th>URL</th><th>Notes</th>
        </tr>
      </thead>
      <tbody>{rows_html}</tbody>
    </table>
  </div>

  <footer>SpondonFW v1.0 &nbsp;|&nbsp; Report generated automatically — verify all findings manually before submission</footer>
</div>
</body>
</html>"""

        out_file = self.output_dir / f"report_{self.session_id[:8]}.html"
        out_file.write_text(html)
        return str(out_file)

    def _generate_json(self, data: Dict) -> str:
        out_file = self.output_dir / f"report_{self.session_id[:8]}.json"
        out_file.write_text(json.dumps(data, indent=2))
        return str(out_file)

    def _generate_markdown(self, data: Dict) -> str:
        lines = [
            f"# SpondonFW Security Report",
            f"",
            f"**Session:** `{data['session_id']}`  ",
            f"**Generated:** {time.strftime('%Y-%m-%d %H:%M:%S')}  ",
            f"**Total Findings:** {data['total']}",
            f"",
            f"## Summary",
            f"",
            f"| Severity | Count |",
            f"|----------|-------|",
        ]
        for sev, cnt in data["summary"].items():
            lines.append(f"| {sev.capitalize()} | {cnt} |")

        lines += ["", "## Findings", ""]
        for f in sorted(data["findings"],
                        key=lambda x: SEVERITY_ORDER.get(x.get("severity","info"), 99)):
            lines.append(f"### [{f.get('severity','info').upper()}] {f.get('type','')}")
            lines.append(f"- **Value:** `{str(f.get('value',''))[:200]}`")
            if f.get("url"):
                lines.append(f"- **URL:** {f['url']}")
            if f.get("evidence"):
                lines.append(f"- **Evidence:** {f['evidence'][:300]}")
            if f.get("notes"):
                lines.append(f"- **Notes:** {f['notes']}")
            lines.append("")

        out_file = self.output_dir / f"report_{self.session_id[:8]}.md"
        out_file.write_text("\n".join(lines))
        return str(out_file)


def _esc(s: str) -> str:
    """HTML escape."""
    return (s.replace("&", "&amp;")
             .replace("<", "&lt;")
             .replace(">", "&gt;")
             .replace('"', "&quot;"))
