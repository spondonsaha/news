"""
SpondonFW - Recon Module: Subdomain Enumeration
Phase 1 of Spondon's Bug Bounty Methodology

Strategy (layered, passive-first):
  1. Passive: crt.sh, SecurityTrails, subfinder (passive), amass passive
  2. Active:  subfinder, amass active, assetfinder, findomain
  3. DNS bruteforce: puredns + wordlist
  4. Permutation: altdns / gotator
  5. HTTP probe: httpx → live subdomains
  6. Screenshot: gowitness (optional)
"""

import os
import re
import json
import time
import requests
from pathlib import Path
from typing import Dict, List, Set

from core.engine.base_module import BaseModule, ModuleResult
from utils.rate_limiter import RateLimiter


class SubdomainEnum(BaseModule):

    name = "recon.subdomains"
    description = "Multi-layer subdomain enumeration: passive OSINT → active brute → HTTP probe"
    category = "recon"
    tools_required = ["subfinder", "amass", "httpx", "puredns", "assetfinder"]
    input_schema = {
        "target": "str — root domain (e.g. example.com)",
        "passive_only": "bool — skip active/bruteforce (default: False)",
        "wordlist": "str — path to bruteforce wordlist",
        "screenshot": "bool — take screenshots with gowitness (default: False)",
    }
    output_schema = {
        "findings": "List of subdomains with liveness status",
        "files": {
            "all_subdomains.txt": "raw deduplicated list",
            "live_subdomains.txt": "httpx-probed live hosts",
            "httpx_output.json": "full httpx JSON output",
        }
    }
    tags = ["recon", "passive", "active", "subdomain", "phase1"]

    # ────────────────────────────────────────────────────────────────────────
    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()

        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)
        passive_only = ctx.get("passive_only", False)
        wordlist = ctx.get("wordlist", "/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt")

        subs: Set[str] = set()

        # ── Step 1: Passive sources ──────────────────────────────────────────
        self.logger.info("Step 1/5 — Passive enumeration")

        # crt.sh
        crt_subs = self._crtsh(target)
        subs.update(crt_subs)
        self.logger.info(f"  crt.sh: {len(crt_subs)} subs")

        # subfinder passive
        if self._tool_available("subfinder"):
            raw = self._run_tool(f"subfinder -d {target} -silent -all -passive", timeout=120)
            found = self._parse_tool_output(raw, target)
            subs.update(found)
            self.logger.info(f"  subfinder (passive): {len(found)} subs")

        # assetfinder
        if self._tool_available("assetfinder"):
            raw = self._run_tool(f"assetfinder --subs-only {target}", timeout=60)
            found = self._parse_tool_output(raw, target)
            subs.update(found)
            self.logger.info(f"  assetfinder: {len(found)} subs")

        # amass passive
        if self._tool_available("amass"):
            raw = self._run_tool(
                f"amass enum -passive -d {target} -silent -o /tmp/amass_passive_{target}.txt",
                timeout=300
            )
            amass_file = f"/tmp/amass_passive_{target}.txt"
            if Path(amass_file).exists():
                found = set(self._read_lines(amass_file))
                subs.update(found)
                self.logger.info(f"  amass (passive): {len(found)} subs")

        # ── Step 2: Active enumeration (skip if passive_only) ───────────────
        if not passive_only:
            self.logger.info("Step 2/5 — Active enumeration")

            if self._tool_available("subfinder"):
                raw = self._run_tool(f"subfinder -d {target} -silent -all", timeout=180)
                found = self._parse_tool_output(raw, target)
                new_found = found - subs
                subs.update(found)
                self.logger.info(f"  subfinder (active): +{len(new_found)} new subs")

        # ── Step 3: DNS bruteforce ───────────────────────────────────────────
        if not passive_only and self._tool_available("puredns") and Path(wordlist).exists():
            self.logger.info("Step 3/5 — DNS bruteforce")
            bf_out = str(out / "bruteforce_subs.txt")
            self._run_tool(
                f"puredns bruteall {wordlist} {target} -q -w {bf_out}",
                timeout=600
            )
            if Path(bf_out).exists():
                found = set(self._read_lines(bf_out))
                new_found = found - subs
                subs.update(found)
                self.logger.info(f"  puredns brute: +{len(new_found)} new subs")
        else:
            self.logger.info("Step 3/5 — DNS bruteforce (skipped)")

        # ── Step 4: Permutation ──────────────────────────────────────────────
        if not passive_only and len(subs) > 0 and self._tool_available("gotator"):
            self.logger.info("Step 4/5 — Permutation generation")
            subs_file = str(out / "subs_for_permutation.txt")
            self._write_lines(subs_file, list(subs))
            perm_out = str(out / "permutated_subs.txt")
            self._run_tool(
                f"gotator -sub {subs_file} -perm /usr/share/seclists/Discovery/DNS/dns-Jhaddix.txt "
                f"-depth 1 -numbers 3 -mindup -adv -md -silent > {perm_out}",
                timeout=300
            )
            if Path(perm_out).exists():
                # Resolve permutations with puredns
                if self._tool_available("puredns"):
                    resolved_out = str(out / "permutation_resolved.txt")
                    self._run_tool(
                        f"puredns resolve {perm_out} -q -w {resolved_out}",
                        timeout=300
                    )
                    if Path(resolved_out).exists():
                        found = set(self._read_lines(resolved_out))
                        new_found = found - subs
                        subs.update(found)
                        self.logger.info(f"  permutation: +{len(new_found)} new subs")
        else:
            self.logger.info("Step 4/5 — Permutation (skipped)")

        # ── Save raw subdomain list ──────────────────────────────────────────
        subs = {s.lower().strip() for s in subs if s and target in s}
        all_subs_file = str(out / "all_subdomains.txt")
        self._write_lines(all_subs_file, sorted(subs))
        self.logger.info(f"Total unique subdomains: {len(subs)}")

        # ── Step 5: HTTP probe with httpx ────────────────────────────────────
        self.logger.info("Step 5/5 — HTTP probing with httpx")
        live_subs_file = str(out / "live_subdomains.txt")
        httpx_json = str(out / "httpx_output.json")
        live_hosts = []

        if self._tool_available("httpx") and len(subs) > 0:
            raw = self._run_tool(
                f"httpx -l {all_subs_file} -silent -json -o {httpx_json} "
                f"-title -tech-detect -status-code -follow-redirects "
                f"-threads 50 -timeout 10",
                timeout=600
            )
            live_hosts = self._parse_httpx_json(httpx_json)
            self._write_lines(live_subs_file, [h["url"] for h in live_hosts])
            self.logger.info(f"Live hosts: {len(live_hosts)}")
        else:
            self.logger.warning("httpx not available or no subdomains found")

        # ── Screenshot with gowitness (optional) ────────────────────────────
        if ctx.get("screenshot", False) and self._tool_available("gowitness") and live_hosts:
            screenshot_dir = str(out / "screenshots")
            Path(screenshot_dir).mkdir(exist_ok=True)
            self._run_tool(
                f"gowitness file -f {live_subs_file} -P {screenshot_dir} --delay 3",
                timeout=600
            )
            self.logger.info(f"Screenshots saved to: {screenshot_dir}")

        # ── Build findings ───────────────────────────────────────────────────
        # Record all subdomains as info findings
        for sub in sorted(subs):
            result.add_finding(
                finding_type="subdomain",
                value=sub,
                severity="info"
            )

        # Flag interesting subdomains
        interesting_patterns = [
            "admin", "api", "dev", "staging", "test", "internal",
            "vpn", "mail", "backup", "db", "database", "jenkins",
            "jira", "gitlab", "bitbucket", "ci", "beta", "old"
        ]
        for host_info in live_hosts:
            url = host_info.get("url", "")
            subdomain = host_info.get("input", "")
            tech = host_info.get("technologies", [])
            title = host_info.get("title", "")
            status = host_info.get("status_code", 0)

            # Flag interesting subdomains
            for pattern in interesting_patterns:
                if pattern in subdomain.lower():
                    result.add_finding(
                        finding_type="interesting_subdomain",
                        value=subdomain,
                        severity="medium",
                        url=url,
                        evidence=f"Pattern match: '{pattern}' | Title: {title} | Status: {status}",
                        notes=f"Technologies: {', '.join(tech) if tech else 'unknown'}"
                    )
                    break

            # Flag admin panels
            if status in (200, 301, 302) and any(
                kw in title.lower() for kw in ["admin", "login", "dashboard", "portal", "console"]
            ):
                result.add_finding(
                    finding_type="admin_panel",
                    value=url,
                    severity="high",
                    url=url,
                    evidence=f"Title: {title} | Status: {status}",
                    notes="Potential admin interface discovered"
                )

        result.metadata = {
            "total_subdomains": len(subs),
            "live_hosts": len(live_hosts),
            "output_files": {
                "all_subdomains": all_subs_file,
                "live_subdomains": live_subs_file,
                "httpx_json": httpx_json,
            }
        }

        result.finished_at = time.time()
        return result

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _crtsh(self, domain: str) -> Set[str]:
        """Query crt.sh certificate transparency logs."""
        subs = set()
        try:
            url = f"https://crt.sh/?q=%.{domain}&output=json"
            resp = requests.get(url, timeout=20)
            if resp.status_code == 200:
                data = resp.json()
                for entry in data:
                    name = entry.get("name_value", "")
                    for sub in name.split("\n"):
                        sub = sub.strip().lower().replace("*.", "")
                        if sub and domain in sub:
                            subs.add(sub)
        except Exception as e:
            self.logger.warning(f"crt.sh query failed: {e}")
        return subs

    def _parse_tool_output(self, raw: str, domain: str) -> Set[str]:
        """Extract subdomains from raw tool output."""
        subs = set()
        pattern = re.compile(
            r'(?:[a-z0-9](?:[a-z0-9\-]{0,61}[a-z0-9])?\.)+' + re.escape(domain),
            re.IGNORECASE
        )
        for match in pattern.findall(raw):
            subs.add(match.lower().strip())
        return subs

    def _parse_httpx_json(self, filepath: str) -> List[Dict]:
        """Parse httpx JSON output line by line."""
        results = []
        if not Path(filepath).exists():
            return results
        with open(filepath) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        results.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return results
