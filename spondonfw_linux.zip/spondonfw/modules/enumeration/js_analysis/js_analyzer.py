"""
SpondonFW - Enumeration Module: JavaScript Analysis
Phase 2 of Spondon's Bug Bounty Methodology

Strategy:
  1. Collect JS file URLs (from crawl output, waybackurls, katana)
  2. Download JS files
  3. Extract:
     - Endpoints / API paths
     - Secrets / API keys (regex patterns)
     - AWS keys, JWT tokens, passwords
     - Internal IPs / hostnames
     - Interesting comments / TODO/FIXME
  4. Deep-link extraction from bundles (webpack, minified)
"""

import re
import json
import time
import requests
from pathlib import Path
from typing import Dict, List, Set, Tuple
from urllib.parse import urljoin, urlparse

from core.engine.base_module import BaseModule, ModuleResult


# Secret detection patterns (inspired by truffleHog, gitleaks)
SECRET_PATTERNS = {
    "aws_access_key":     r"(?:A3T[A-Z0-9]|AKIA|AGPA|AIDA|AROA|AIPA|ANPA|ANVA|ASIA)[A-Z0-9]{16}",
    "aws_secret_key":     r"(?i)aws[_\-\s]?secret[_\-\s]?(?:access[_\-\s]?)?key[\"'\s]*[:=][\"'\s]*([A-Za-z0-9/+=]{40})",
    "github_token":       r"ghp_[A-Za-z0-9_]{36}",
    "github_oauth":       r"gho_[A-Za-z0-9_]{36}",
    "slack_token":        r"xox[baprs]-[A-Za-z0-9-]+",
    "slack_webhook":      r"https://hooks\.slack\.com/services/[A-Za-z0-9/]+",
    "google_api_key":     r"AIza[0-9A-Za-z\-_]{35}",
    "firebase":           r"AAAA[A-Za-z0-9_-]{7}:[A-Za-z0-9_-]{140}",
    "jwt_token":          r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9._-]+",
    "generic_api_key":    r"(?i)(?:api|access|secret|token|passwd|password|auth)[_\-\s]?key[\"'\s]*[:=][\"'\s]*([A-Za-z0-9_\-]{16,64})",
    "private_key":        r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----",
    "basic_auth":         r"(?i)(?:https?://)[A-Za-z0-9_]+:[A-Za-z0-9_!@#$%^&*]+@",
    "internal_ip":        r"(?:10\.|172\.(?:1[6-9]|2\d|3[01])\.|192\.168\.)\d{1,3}\.\d{1,3}",
    "stripe_live_key":    r"sk_live_[A-Za-z0-9]{24,}",
    "stripe_pub_key":     r"pk_live_[A-Za-z0-9]{24,}",
    "sendgrid_key":       r"SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}",
    "mailchimp_key":      r"[0-9a-f]{32}-us[0-9]{1,2}",
    "heroku_api_key":     r"(?i)heroku[_\s]*(?:api[_\s]*)?key[\"'\s]*[:=][\"'\s]*[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
    "twilio_sid":         r"AC[A-Za-z0-9_\-]{32}",
    "npm_token":          r"npm_[A-Za-z0-9]{36}",
}

# Endpoint extraction patterns
ENDPOINT_PATTERNS = [
    r'(?:"|\'|`)(/(?:api|v[0-9]+|admin|user|auth|upload|download|webhook|graphql|rest)[^\s"\'`\)]*)',
    r'fetch\(["\']([^"\']+)["\']',
    r'axios\.(?:get|post|put|delete|patch)\(["\']([^"\']+)["\']',
    r'url\s*[:=]\s*["\']([^"\']+)["\']',
    r'endpoint\s*[:=]\s*["\']([^"\']+)["\']',
    r'baseURL\s*[:=]\s*["\']([^"\']+)["\']',
    r'href\s*[:=]\s*["\']([^"\']+)["\']',
    r'(?:XMLHttpRequest|XHR).*?open\(["\'][A-Z]+["\'],\s*["\']([^"\']+)["\']',
]


class JSAnalyzer(BaseModule):

    name = "enum.js_analysis"
    description = "Extract endpoints, secrets, API keys and interesting data from JavaScript files"
    category = "enumeration"
    tools_required = ["katana", "waybackurls", "subjs", "linkfinder"]
    input_schema = {
        "target": "str — domain",
        "urls_file": "str (optional) — file with live URLs to crawl for JS",
        "js_urls_file": "str (optional) — pre-collected list of .js URLs",
        "deep_analysis": "bool — run LinkFinder on all JS files (slower)",
    }
    output_schema = {
        "findings": "Secrets, endpoints, and interesting patterns found",
        "files": {
            "js_urls.txt": "all discovered .js file URLs",
            "endpoints.txt": "extracted API endpoints",
            "secrets.json": "discovered secrets by type",
        }
    }
    tags = ["enumeration", "javascript", "secrets", "endpoints", "phase2"]

    def execute(self, ctx: Dict) -> ModuleResult:
        result = ModuleResult(module_name=self.name, target=ctx["target"])
        result.started_at = time.time()

        target = ctx["target"]
        out = Path(ctx["output_dir"])
        out.mkdir(parents=True, exist_ok=True)

        js_urls: Set[str] = set()

        # ── Step 1: Collect JS file URLs ─────────────────────────────────────
        self.logger.info("Step 1/3 — Collecting JS file URLs")

        # Use pre-supplied file if available
        if ctx.get("js_urls_file") and Path(ctx["js_urls_file"]).exists():
            js_urls.update(self._read_lines(ctx["js_urls_file"]))

        # From supplied URLs file (live hosts)
        if ctx.get("urls_file") and Path(ctx["urls_file"]).exists():
            urls = self._read_lines(ctx["urls_file"])
            for url in urls[:50]:  # limit scope
                found = self._extract_js_from_page(url)
                js_urls.update(found)

        # subjs — extracts JS from pages
        if self._tool_available("subjs"):
            if ctx.get("urls_file"):
                raw = self._run_tool(
                    f"subjs -i {ctx['urls_file']} -silent",
                    timeout=300
                )
                for line in raw.splitlines():
                    line = line.strip()
                    if line.endswith(".js") or ".js?" in line:
                        js_urls.add(line)

        # katana spider
        if self._tool_available("katana"):
            raw = self._run_tool(
                f"katana -u https://{target} -silent -js-crawl -depth 3 "
                f"-extension-filter jpg,png,gif,svg,css,woff -no-color",
                timeout=300
            )
            for line in raw.splitlines():
                line = line.strip()
                if ".js" in line:
                    js_urls.add(line)

        # waybackurls for historical JS
        if self._tool_available("waybackurls"):
            raw = self._run_tool(f"waybackurls {target}", timeout=120)
            for line in raw.splitlines():
                line = line.strip()
                if line.endswith(".js"):
                    js_urls.add(line)

        js_urls_file = str(out / "js_urls.txt")
        self._write_lines(js_urls_file, sorted(js_urls))
        self.logger.info(f"JS files collected: {len(js_urls)}")

        # ── Step 2: Download & analyze each JS file ──────────────────────────
        self.logger.info("Step 2/3 — Analyzing JS files")

        all_endpoints: Set[str] = set()
        all_secrets: List[Dict] = []
        js_dir = out / "js_files"
        js_dir.mkdir(exist_ok=True)

        for js_url in list(js_urls)[:200]:  # cap at 200 to avoid runaway
            try:
                content = self._fetch_js(js_url)
                if not content:
                    continue

                # Extract endpoints
                endpoints = self._extract_endpoints(content, js_url)
                all_endpoints.update(endpoints)

                # Extract secrets
                secrets = self._extract_secrets(content, js_url)
                all_secrets.extend(secrets)

                # Save JS file locally
                safe_name = re.sub(r'[^\w\-]', '_', js_url)[-100:]
                js_file = js_dir / f"{safe_name}.js"
                with open(js_file, "w", errors="ignore") as f:
                    f.write(content)

            except Exception as e:
                self.logger.debug(f"Failed to analyze {js_url}: {e}")

        # ── Step 3: LinkFinder deep analysis ─────────────────────────────────
        if ctx.get("deep_analysis", False) and self._tool_available("python3"):
            self.logger.info("Step 3/3 — LinkFinder deep analysis")
            for js_file in js_dir.glob("*.js"):
                lf_out = str(out / f"linkfinder_{js_file.stem}.txt")
                raw = self._run_tool(
                    f"python3 -m linkfinder -i {js_file} -o cli 2>/dev/null",
                    timeout=30
                )
                for line in raw.splitlines():
                    line = line.strip()
                    if line and (line.startswith("/") or line.startswith("http")):
                        all_endpoints.add(line)
        else:
            self.logger.info("Step 3/3 — LinkFinder (skipped, use --args '{\"deep_analysis\": true}')")

        # ── Save outputs ─────────────────────────────────────────────────────
        endpoints_file = str(out / "endpoints.txt")
        self._write_lines(endpoints_file, sorted(all_endpoints))

        secrets_file = str(out / "secrets.json")
        with open(secrets_file, "w") as f:
            json.dump(all_secrets, f, indent=2)

        self.logger.info(f"Endpoints found: {len(all_endpoints)}")
        self.logger.info(f"Potential secrets found: {len(all_secrets)}")

        # ── Build findings ───────────────────────────────────────────────────
        for endpoint in all_endpoints:
            sev = "info"
            if any(kw in endpoint.lower() for kw in
                   ["admin", "internal", "secret", "password", "token", "debug"]):
                sev = "medium"
            result.add_finding(
                finding_type="endpoint",
                value=endpoint,
                severity=sev,
                notes="Extracted from JavaScript file"
            )

        for secret in all_secrets:
            result.add_finding(
                finding_type="potential_secret",
                value=f"{secret['type']}: {secret['value'][:60]}...",
                severity="high",
                url=secret["source_url"],
                evidence=f"Pattern: {secret['type']}",
                notes="Verify before reporting — may be a false positive"
            )

        result.metadata = {
            "js_files_analyzed": len(js_urls),
            "endpoints_found": len(all_endpoints),
            "secrets_found": len(all_secrets),
            "output_files": {
                "js_urls": js_urls_file,
                "endpoints": endpoints_file,
                "secrets": secrets_file,
            }
        }

        result.finished_at = time.time()
        return result

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _fetch_js(self, url: str, timeout: int = 10) -> str:
        try:
            headers = {"User-Agent": "Mozilla/5.0 (SpondonFW/1.0)"}
            resp = requests.get(url, headers=headers, timeout=timeout, verify=False)
            if resp.status_code == 200:
                return resp.text
        except Exception:
            pass
        return ""

    def _extract_js_from_page(self, url: str) -> Set[str]:
        """Fetch a page and extract <script src="..."> URLs."""
        js_urls = set()
        try:
            resp = requests.get(url, timeout=10, verify=False,
                                headers={"User-Agent": "Mozilla/5.0"})
            src_pattern = re.compile(r'<script[^>]+src=["\']([^"\']+\.js[^"\']*)["\']',
                                     re.IGNORECASE)
            base = f"{urlparse(url).scheme}://{urlparse(url).netloc}"
            for match in src_pattern.findall(resp.text):
                if match.startswith("http"):
                    js_urls.add(match)
                elif match.startswith("/"):
                    js_urls.add(base + match)
                else:
                    js_urls.add(urljoin(url, match))
        except Exception:
            pass
        return js_urls

    def _extract_endpoints(self, content: str, source_url: str) -> Set[str]:
        endpoints = set()
        for pattern in ENDPOINT_PATTERNS:
            for match in re.findall(pattern, content):
                match = match.strip()
                if len(match) > 3 and len(match) < 200:
                    # Filter out common non-endpoint patterns
                    if not any(ext in match.lower() for ext in
                               [".png", ".jpg", ".gif", ".css", ".woff", ".svg"]):
                        endpoints.add(match)
        return endpoints

    def _extract_secrets(self, content: str, source_url: str) -> List[Dict]:
        found = []
        for secret_type, pattern in SECRET_PATTERNS.items():
            matches = re.findall(pattern, content)
            for match in matches:
                value = match if isinstance(match, str) else match[0]
                if len(value) > 8:  # avoid very short false positives
                    found.append({
                        "type": secret_type,
                        "value": value,
                        "source_url": source_url,
                    })
        return found
