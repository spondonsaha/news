"""
SpondonFW - Utility: Config Parser
Loads and validates YAML/JSON config files with defaults.
"""

import yaml
import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

DEFAULT_CONFIG = {
    "framework": {
        "version": "1.0.0",
        "debug": False,
        "log_level": "INFO",
        "log_file": "logs/spondonfw.log",
    },
    "execution": {
        "rate_limit": 10,
        "default_timeout": 3600,
        "max_retries": 3,
        "parallel_stages": 1,
        "user_agent": "SpondonFW/1.0 (Bug Bounty Framework)",
    },
    "database": {
        "type": "sqlite",                         # sqlite | postgresql | mongodb
        "sqlite_path": "data/spondonfw.db",
        "postgres_url": "",
        "mongo_url": "",
    },
    "tools": {
        "subfinder": {"enabled": True},
        "amass":     {"enabled": True},
        "httpx":     {"enabled": True},
        "nuclei":    {"enabled": True},
        "dalfox":    {"enabled": True},
        "ffuf":      {"enabled": True},
        "sqlmap":    {"enabled": False},   # disabled by default — noisy
        "katana":    {"enabled": True},
        "gau":       {"enabled": True},
        "waybackurls":{"enabled": True},
        "puredns":   {"enabled": True},
        "assetfinder":{"enabled": True},
        "arjun":     {"enabled": True},
        "shodan":    {"enabled": False},   # requires API key
    },
    "output": {
        "directory": "results/",
        "report_directory": "reports/",
        "formats": ["html", "json"],
        "compress_after": True,
    },
    "notifications": {
        "enabled": False,
        "slack_webhook": "",
        "discord_webhook": "",
        "telegram_bot_token": "",
        "telegram_chat_id": "",
    },
}


class ConfigParser:
    """Load, merge, and access framework configuration."""

    def __init__(self, config_path: Optional[str] = None):
        self._config = dict(DEFAULT_CONFIG)
        if config_path:
            self.load(config_path)

        # Also load from environment variables
        self._load_env_overrides()

    def load(self, path: str) -> None:
        p = Path(path)
        if not p.exists():
            return
        with open(p) as f:
            if path.endswith(".yaml") or path.endswith(".yml"):
                user_config = yaml.safe_load(f) or {}
            else:
                user_config = json.load(f)
        self._deep_merge(self._config, user_config)

    def get(self, key_path: str, default: Any = None) -> Any:
        """Get config value by dotted path, e.g. 'database.type'"""
        keys = key_path.split(".")
        val = self._config
        for k in keys:
            if isinstance(val, dict) and k in val:
                val = val[k]
            else:
                return default
        return val

    def _deep_merge(self, base: Dict, override: Dict) -> None:
        for key, val in override.items():
            if key in base and isinstance(base[key], dict) and isinstance(val, dict):
                self._deep_merge(base[key], val)
            else:
                base[key] = val

    def _load_env_overrides(self):
        """Load API keys and settings from environment variables."""
        env_map = {
            "SHODAN_API_KEY":    "api_keys.shodan",
            "GITHUB_TOKEN":      "api_keys.github",
            "CENSYS_API_ID":     "api_keys.censys_id",
            "CENSYS_API_SECRET": "api_keys.censys_secret",
            "SLACK_WEBHOOK":     "notifications.slack_webhook",
        }
        for env_var, config_path in env_map.items():
            val = os.environ.get(env_var)
            if val:
                keys = config_path.split(".")
                d = self._config
                for k in keys[:-1]:
                    d = d.setdefault(k, {})
                d[keys[-1]] = val

    @staticmethod
    def scaffold(output_path: str = "config/user.yaml"):
        """Write a starter config file."""
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        starter = {
            "execution": {
                "rate_limit": 10,
            },
            "database": {
                "type": "sqlite",
            },
            "api_keys": {
                "shodan": "YOUR_SHODAN_KEY",
                "github": "YOUR_GITHUB_TOKEN",
                "censys_id": "",
                "censys_secret": "",
            },
            "notifications": {
                "enabled": False,
                "slack_webhook": "",
            }
        }
        with open(output_path, "w") as f:
            yaml.dump(starter, f, default_flow_style=False)
        print(f"Config scaffolded: {output_path}")
